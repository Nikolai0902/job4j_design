package ru.job4j.exam;

import java.nio.file.Files;
import java.nio.file.Path;

public class SearchCriterion {
    public static void main(String[] args) {
        valid(args);
    }

    private static void valid(String[] args) {
        if (!Files.isDirectory(Path.of(args[0]))) {
            throw new IllegalArgumentException("parameter is not a dirrectory");
        }
        if (!args[1].startsWith(".")) {
            throw new IllegalArgumentException("format file of the parameters is incorrect");
        }
    }
}
