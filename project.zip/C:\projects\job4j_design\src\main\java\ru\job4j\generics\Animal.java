package ru.job4j.generics;

public class Animal {

    public Animal() {
        System.out.println("Hello World");
    }
}
